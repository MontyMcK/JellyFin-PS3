// player.cpp — Jellyfin PS3 media player
// Video: H.264 hardware decode via PSL1GHT VDEC
// Audio: PCM silence output (keeps audio timeline alive; real decode is a future TODO)
// Container: MPEG-TS requested from Jellyfin transcoder

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <time.h>

// -------------------------------------------------------
// Debug log — survives crashes, written before each step
// -------------------------------------------------------

static FILE *s_plog = NULL;
static void plog(const char *msg) {
    if (!s_plog) s_plog = fopen("/dev_hdd0/tmp/player_log.txt", "w");
    if  (s_plog) {
        time_t t = time(NULL);
        struct tm *tm = localtime(&t);
        fprintf(s_plog, "[%04d-%02d-%02d %02d:%02d:%02d] %s\n",
                tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
                tm->tm_hour, tm->tm_min, tm->tm_sec, msg);
        fflush(s_plog);
    }
}

#include <ppu-types.h>
#include <ppu-asm.h>
#include <io/pad.h>
#include <sysutil/sysutil.h>
#include <sysmodule/sysmodule.h>
#include <net/net.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/event_queue.h>

#include <codec/vdec.h>
#include <audio/audio.h>

#include "player.h"
#include "ui.h"
#include "jellyfin_api.h"
#include "http.h"

// -------------------------------------------------------
// MPEG-TS demuxer
// -------------------------------------------------------

#define TS_PACKET_SIZE   188
#define TS_SYNC_BYTE     0x47
#define TS_PID_PAT       0x0000
#define TS_STREAM_H264   0x1B

typedef struct {
    u16  pmt_pid;
    u16  video_pid;

    // PES reassembly buffer for one complete video PES packet
    u8   pes_buf[512 * 1024];
    int  pes_len;
    bool pes_started;
} TSState;

static void ts_parse_pat(TSState *ts, const u8 *data, int len) {
    if (len < 12 || data[0] != 0x00) return;
    u16 sec_len = ((u16)(data[1] & 0x0F) << 8) | data[2];
    int end = 3 + (int)sec_len - 4; // subtract 4-byte CRC
    if (end > len) end = len;
    int pos = 8;
    while (pos + 3 < end) {
        u16 prog = ((u16)data[pos] << 8) | data[pos+1];
        u16 pid  = ((u16)(data[pos+2] & 0x1F) << 8) | data[pos+3];
        if (prog != 0) { ts->pmt_pid = pid; return; }
        pos += 4;
    }
}

static void ts_parse_pmt(TSState *ts, const u8 *data, int len) {
    if (len < 16 || data[0] != 0x02) return;
    u16 sec_len      = ((u16)(data[1] & 0x0F) << 8) | data[2];
    int end          = 3 + (int)sec_len - 4;
    if (end > len) end = len;
    u16 prog_info    = ((u16)(data[10] & 0x0F) << 8) | data[11];
    int pos          = 12 + prog_info;
    while (pos + 4 < end) {
        u8  stype  = data[pos];
        u16 epid   = ((u16)(data[pos+1] & 0x1F) << 8) | data[pos+2];
        u16 esinfo = ((u16)(data[pos+3] & 0x0F) << 8) | data[pos+4];
        if (stype == TS_STREAM_H264 && !ts->video_pid) {
            ts->video_pid = epid;
            return;
        }
        pos += 5 + esinfo;
    }
}

// Process one 188-byte TS packet.
// Returns true + fills out_pes/out_len when a complete PES is ready.
static bool ts_process(TSState *ts, const u8 *pkt, u8 *out_pes, int *out_len) {
    if (pkt[0] != TS_SYNC_BYTE) return false;

    bool pusi    = (pkt[1] & 0x40) != 0;
    u16  pid     = ((u16)(pkt[1] & 0x1F) << 8) | pkt[2];
    u8   afl     = (pkt[3] >> 4) & 3;
    bool has_pay = (afl & 1) != 0;
    if (!has_pay) return false;

    int  off = 4;
    if (afl & 2) off += pkt[4] + 1;
    if (off >= TS_PACKET_SIZE) return false;

    const u8 *pay = pkt + off;
    int       plen = TS_PACKET_SIZE - off;

    // PAT
    if (pid == TS_PID_PAT && pusi && !ts->pmt_pid) {
        int ptr = pay[0];
        if (ptr + 1 < plen) ts_parse_pat(ts, pay + 1 + ptr, plen - 1 - ptr);
        return false;
    }
    // PMT
    if (ts->pmt_pid && pid == ts->pmt_pid && pusi && !ts->video_pid) {
        int ptr = pay[0];
        if (ptr + 1 < plen) ts_parse_pmt(ts, pay + 1 + ptr, plen - 1 - ptr);
        return false;
    }
    // Video PES
    if (!ts->video_pid || pid != ts->video_pid) return false;

    bool ready = false;
    if (pusi && ts->pes_started && ts->pes_len > 0) {
        // Previous PES complete — emit it
        int copy = ts->pes_len < (int)sizeof(ts->pes_buf) ? ts->pes_len : (int)sizeof(ts->pes_buf);
        memcpy(out_pes, ts->pes_buf, copy);
        *out_len = copy;
        ready = true;
        ts->pes_len = 0;
    }
    if (pusi) { ts->pes_started = true; ts->pes_len = 0; }

    if (ts->pes_started && plen > 0) {
        int room = (int)sizeof(ts->pes_buf) - ts->pes_len;
        int copy = plen < room ? plen : room;
        memcpy(ts->pes_buf + ts->pes_len, pay, copy);
        ts->pes_len += copy;
    }
    return ready;
}

// Strip the PES header and return a pointer into the H.264 payload.
static bool pes_payload(const u8 *pes, int pes_len, const u8 **h264, int *h264_len) {
    if (pes_len < 9) return false;
    if (pes[0] != 0x00 || pes[1] != 0x00 || pes[2] != 0x01) return false;
    int hdr = 9 + pes[8];
    if (hdr >= pes_len) return false;
    *h264     = pes + hdr;
    *h264_len = pes_len - hdr;
    return true;
}

// -------------------------------------------------------
// HTTP streaming (keep socket open for continuous read)
// -------------------------------------------------------

static bool s_chunked      = false;
static int  s_chunk_remain = -1; // -1 = need first chunk header
static char s_chdr[32];          // partial chunk-size line accumulator
static int  s_chdr_n      = 0;   // bytes accumulated in s_chdr
static int  s_ctrail       = 0;   // trailing CRLF bytes left after chunk data

static int stream_open(const char *url) {
    // Inline URL parse (url_parse is static in http.cpp)
    const char *p = url;
    if (strncmp(p, "http://", 7) == 0) p += 7;

    char host[256]; int port = 8096; char path[512];
    const char *h = p;
    while (*p && *p != ':' && *p != '/') p++;
    int hl = p - h; if (hl >= 255) hl = 255;
    memcpy(host, h, hl); host[hl] = '\0';
    if (*p == ':') { p++; port = atoi(p); while (*p && *p != '/') p++; }
    strncpy(path, *p ? p : "/", sizeof(path)-1); path[sizeof(path)-1] = '\0';

    int sock = netSocket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0) return -1;

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port   = htons((u16)port);
    unsigned na=0,nb=0,nc=0,nd=0;
    sscanf(host, "%u.%u.%u.%u", &na, &nb, &nc, &nd);
    addr.sin_addr.s_addr = htonl((na<<24)|(nb<<16)|(nc<<8)|nd);

    if (netConnect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        netClose(sock); return -1;
    }

    char auth[400];
    if (g_token[0])
        snprintf(auth, sizeof(auth),
            "MediaBrowser Client=\"PS3\", Device=\"PS3\","
            " DeviceId=\"ps3\", Version=\"0.1\", Token=\"%s\"", g_token);
    else
        snprintf(auth, sizeof(auth),
            "MediaBrowser Client=\"PS3\", Device=\"PS3\","
            " DeviceId=\"ps3\", Version=\"0.1\"");

    char req[2048];
    int rlen = snprintf(req, sizeof(req),
        "GET %s HTTP/1.1\r\n"
        "Host: %s:%d\r\n"
        "X-Emby-Authorization: %s\r\n"
        "Accept: video/mp2t\r\n"
        "User-Agent: " HTTP_USER_AGENT "\r\n"
        "Connection: close\r\n"
        "\r\n",
        path, host, port, auth);
    netSend(sock, req, rlen, 0);

    // Read response headers byte-by-byte until \r\n\r\n
    char hdr[4096]; int htotal = 0;
    while (htotal < (int)sizeof(hdr)-1) {
        if (netRecv(sock, hdr + htotal, 1, 0) != 1) { netClose(sock); return -1; }
        htotal++;
        if (htotal >= 4 && memcmp(hdr + htotal - 4, "\r\n\r\n", 4) == 0) break;
    }
    hdr[htotal] = '\0';

    // Check HTTP 200
    if (strncmp(hdr, "HTTP/", 5) == 0) {
        char *sp = strchr(hdr, ' ');
        if (sp && atoi(sp+1) != 200) { netClose(sock); return -1; }
    }

    // Log status line and detect chunked transfer encoding
    s_chunked      = (strstr(hdr, "chunked") != NULL);
    s_chunk_remain = -1; // -1 = waiting for first chunk header
    s_chdr_n       = 0;
    s_ctrail       = 0;
    {
        char status[32] = "?";
        if (strncmp(hdr, "HTTP/", 5) == 0) {
            char *sp = strchr(hdr, ' ');
            if (sp) { strncpy(status, sp+1, 12); status[12] = '\0'; }
        }
        char buf2[64];
        snprintf(buf2, sizeof(buf2), "stream_open: status=%s chunked=%d", status, (int)s_chunked);
        plog(buf2);
    }

    // 500 ms receive timeout so the button check runs even when data stalls
    struct { u32 sec; u32 usec; } tv = { 0, 500000 };
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    return sock;
}

// Read exactly 'size' bytes, transparently decoding chunked transfer encoding.
// Fully resumable: all state lives in statics so any timeout returns 0 cleanly.
// Returns:  1 = success
//           0 = timed out — caller checks buttons then calls again
//          -1 = disconnect or terminal chunk
static int stream_read(int sock, u8 *buf, int size) {
    int got = 0;
    while (got < size) {
        if (!s_chunked) {
            int n = netRecv(sock, buf + got, size - got, 0);
            if (n == 0) return -1;
            if (n <  0) return  0;
            got += n;
            continue;
        }

        // State 1: consume trailing CRLF after a chunk's data
        if (s_ctrail > 0) {
            u8 c;
            int n = netRecv(sock, &c, 1, 0);
            if (n == 0) return -1;
            if (n <  0) return  0; // timeout — return so buttons can be checked
            s_ctrail--;
            continue;
        }

        // State 2: read chunk-size header line one byte at a time.
        // s_chdr/s_chdr_n persist across calls so we resume mid-line on timeout.
        if (s_chunk_remain <= 0) {
            u8 c;
            int n = netRecv(sock, &c, 1, 0);
            if (n == 0) return -1;
            if (n <  0) return  0; // timeout — return so buttons can be checked
            if (c == '\n') {
                int llen = s_chdr_n;
                while (llen > 0 && (s_chdr[llen-1] == '\r' || s_chdr[llen-1] == ' '))
                    llen--;
                s_chdr[llen] = '\0';
                s_chunk_remain = (int)strtol(s_chdr, NULL, 16);
                s_chdr_n = 0;
                if (s_chunk_remain == 0) return -1; // terminal chunk
            } else if (s_chdr_n < (int)sizeof(s_chdr) - 1) {
                s_chdr[s_chdr_n++] = (char)c;
            }
            continue; // loop: either need more header bytes, or now read data
        }

        // State 3: read chunk data
        int want = size - got;
        if (want > s_chunk_remain) want = s_chunk_remain;
        int n = netRecv(sock, buf + got, want, 0);
        if (n == 0) return -1;
        if (n <  0) return  0;
        got            += n;
        s_chunk_remain -= n;
        if (s_chunk_remain == 0)
            s_ctrail = 2; // schedule CRLF consumption
    }
    return 1;
}

// -------------------------------------------------------
// VDEC — video decoder
// -------------------------------------------------------

#define AU_BUF_SIZE  (512 * 1024)
#define AU_BUF_COUNT 4            // ring so VDEC can read each buffer async

static u32   s_vdec     = 0;
static u8   *s_vdec_mem = NULL;
static u8   *s_au_bufs[AU_BUF_COUNT] = {};  // ring of AU input buffers
static int   s_au_buf_idx = 0;               // next ring slot to write
static u8   *s_frame_buf = NULL;  // decoded ARGB32 output

// 32-bit OPD for the VDEC callback — must outlive vdec_open().
// Native cellVdec dispatches via: lwz r0,0(fn); lwz r2,4(fn); mtctr r0; bctrl.
// PSL1GHT is ELF64 PPC so function pointers are 64-bit OPD addresses; we must
// build a {u32 code, u32 toc} descriptor that native's lwz reads correctly.
static opd32 s_vdec_cb_opd32;

// Written by VDEC callback (separate thread) — volatile for visibility
static volatile int  s_frames_ready = 0;
static volatile int  s_au_done      = 0;
static volatile bool s_vdec_error   = false;

static u32 vdec_cb(u32 handle, u32 msgtype, u32 msgdata, u32 arg) {
    (void)handle; (void)msgdata; (void)arg;
    switch (msgtype) {
    case VDEC_CALLBACK_PICOUT:  s_frames_ready++; break;
    case VDEC_CALLBACK_AUDONE:  s_au_done++;      break;
    case VDEC_CALLBACK_SEQDONE: break;
    case VDEC_CALLBACK_ERROR:   s_vdec_error = true; break;
    }
    return 0;
}

static bool vdec_open(void) {
    // Load base VDEC framework first, then the H.264 codec plugin.
    // Do NOT load SYSMODULE_SPURS manually — vdecOpen creates its own SPURS
    // context internally and a pre-existing one causes 0x80610180.
    plog("vdec_open: load VDEC base");
    s32 r1 = sysModuleLoad(SYSMODULE_VDEC);
    plog("vdec_open: load VDEC_H264");
    s32 r2 = sysModuleLoad(SYSMODULE_VDEC_H264);
    { char buf[64]; snprintf(buf,sizeof(buf),"vdec_open: mod_ret base=%d h264=%d",(int)r1,(int)r2); plog(buf); }

    vdecType codec;
    codec.codec_type    = VDEC_CODEC_TYPE_H264;
    codec.profile_level = 31; // H.264 level 3.1 — required for 1280x720 @ 30fps

    plog("vdec_open: queryAttr");
    vdecAttr attr;
    s32 qret = vdecQueryAttr(&codec, &attr);
    if (qret != 0) {
        char buf[64]; snprintf(buf, sizeof(buf), "vdec_open: queryAttr FAILED ret=%d", (int)qret);
        plog(buf); return false;
    }
    { char buf[64]; snprintf(buf, sizeof(buf), "vdec_open: mem_size=%u", attr.mem_size); plog(buf); }

    // Round up to 1 MB so cfg.mem_size matches the actual allocation.
    u32 mem_size_aligned = (attr.mem_size + (1024*1024-1)) & ~(u32)(1024*1024-1);
    plog("vdec_open: memalign vdec_mem");
    s_vdec_mem = (u8*)memalign(1024*1024, mem_size_aligned);
    if (!s_vdec_mem) { plog("vdec_open: vdec_mem alloc FAILED"); return false; }

    plog("vdec_open: memalign au_bufs");
    for (int i = 0; i < AU_BUF_COUNT; i++) {
        s_au_bufs[i] = (u8*)memalign(128, AU_BUF_SIZE);
        if (!s_au_bufs[i]) { plog("vdec_open: au_buf alloc FAILED"); return false; }
    }
    s_au_buf_idx = 0;

    plog("vdec_open: memalign frame_buf");
    s_frame_buf = (u8*)memalign(128, display_width * display_height * 4);
    if (!s_frame_buf) { plog("vdec_open: frame_buf alloc FAILED"); return false; }

    vdecConfig cfg;
    cfg.mem_addr              = (u32)(uintptr_t)s_vdec_mem;
    cfg.mem_size              = mem_size_aligned;
    cfg.ppu_thread_prio       = 1000;
    cfg.ppu_thread_stack_size = 0x40000;  // 256 KB — 64 KB was too small
    cfg.spu_thread_prio       = 250;
    cfg.num_spus              = 1; // 4 causes CELL_VDEC_ERROR_FATAL — too few SPUs available in homebrew

    // Native cellVdecOpen reads cbFunc as a u32 (first 4 bytes of vdecClosure) and
    // dispatches via 32-bit OPD: lwz r0,0(fn); lwz r2,4(fn); mtctr r0; bctrl.
    // PSL1GHT ELF64 function pointers are 64-bit OPD addresses {u64 code, u64 toc};
    // __build_opd32 shrinks that into a static {u32 code, u32 toc} descriptor and
    // returns its address as a u32, which is what fn must hold.
    vdecClosure closure;
    closure.fn  = __build_opd32((opd64*)(uintptr_t)(vdecCallback)vdec_cb, &s_vdec_cb_opd32);
    closure.arg = 0;

    {
        char buf[128];
        snprintf(buf, sizeof(buf),
            "cfg: addr=0x%08x size=%u(%u) prio=%u stack=0x%x spu_prio=%u spus=%u",
            cfg.mem_addr, cfg.mem_size, attr.mem_size,
            cfg.ppu_thread_prio, cfg.ppu_thread_stack_size,
            cfg.spu_thread_prio, cfg.num_spus);
        plog(buf);
    }
    { char buf[80]; snprintf(buf, sizeof(buf), "vdec_cb_opd32: code=0x%08x toc=0x%08x fn=0x%08x",
        (unsigned)s_vdec_cb_opd32.func, (unsigned)s_vdec_cb_opd32.rtoc, (unsigned)closure.fn); plog(buf); }
    plog("vdec_open: vdecOpen");
    s32 oret = vdecOpen(&codec, &cfg, &closure, &s_vdec);
    if (oret != 0) {
        char buf[64]; snprintf(buf, sizeof(buf), "vdec_open: vdecOpen FAILED ret=%d", (int)oret);
        plog(buf); return false;
    }

    s_frames_ready = 0;
    s_au_done      = 0;
    s_vdec_error   = false;

    plog("vdec_open: startSequence");
    s32 sret = vdecStartSequence(s_vdec);
    { char buf[64]; snprintf(buf, sizeof(buf), "vdec_open: startSequence ret=%d", (int)sret); plog(buf); }
    if (sret != 0) { plog("vdec_open: startSequence FAILED"); return false; }
    plog("vdec_open: done");
    return true;
}

static void vdec_close(void) {
    if (s_vdec) {
        vdecEndSequence(s_vdec);
        vdecClose(s_vdec);
        s_vdec = 0;
    }
    if (s_vdec_mem)  { free(s_vdec_mem);  s_vdec_mem  = NULL; }
    for (int i = 0; i < AU_BUF_COUNT; i++) {
        if (s_au_bufs[i]) { free(s_au_bufs[i]); s_au_bufs[i] = NULL; }
    }
    if (s_frame_buf) { free(s_frame_buf); s_frame_buf = NULL; }

    sysModuleUnload(SYSMODULE_VDEC_H264);
    sysModuleUnload(SYSMODULE_VDEC);
}

static int  s_au_submitted = 0;
static bool s_got_sps      = false;

// Submit one H.264 access unit to VDEC.
// Scans the AU for NAL types; withholds submission until SPS (type 7) is seen.
static void vdec_submit(const u8 *data, int len) {
    if (len <= 0 || len > AU_BUF_SIZE) return;

    // Walk start codes to find first NAL type and check for SPS / IDR
    u8   nal_first = 0;
    bool has_sps   = false;
    bool has_idr   = false;
    for (int i = 0; i + 3 < len; i++) {
        if (data[i] != 0x00 || data[i+1] != 0x00) continue;
        u8 nal = 0;
        if (                   data[i+2] == 0x01 && i+3 < len) nal = data[i+3] & 0x1f;
        else if (data[i+2]==0 && data[i+3]==0x01 && i+4 < len) nal = data[i+4] & 0x1f;
        else continue;
        if (!nal_first) nal_first = nal;
        if (nal == 7) has_sps = true;
        if (nal == 5) has_idr = true;
    }
    if (has_sps) s_got_sps = true;

    // Log first 10 AUs, every 100 after that, and any AU with SPS or IDR
    if (s_au_submitted < 10 || (s_au_submitted % 100 == 0) || has_sps || has_idr) {
        char buf[96];
        snprintf(buf, sizeof(buf),
            "AU#%d len=%d nal0=%d sps=%d idr=%d got_sps=%d",
            s_au_submitted, len, nal_first, has_sps, has_idr, s_got_sps);
        plog(buf);
    }

    s_au_submitted++;

    // VDEC needs SPS before it will accept slice data
    if (!s_got_sps) return;

    // Use a ring of AU buffers — VDEC reads each buffer asynchronously on the SPU,
    // so we must not overwrite it before the decode is done.
    u8 *au_buf = s_au_bufs[s_au_buf_idx % AU_BUF_COUNT];
    s_au_buf_idx++;
    memcpy(au_buf, data, len);

    vdecAU au;
    memset(&au, 0, sizeof(au));
    au.packet_addr = (u32)(uintptr_t)au_buf;
    au.packet_size = (u32)len;
    au.pts.low     = VDEC_TS_INVALID;
    au.pts.hi      = 0;
    au.dts.low     = VDEC_TS_INVALID;
    au.dts.hi      = 0;

    int retries = 0;
    s32 dret;
    do {
        dret = vdecDecodeAu(s_vdec, VDEC_DECODER_MODE_NORMAL, &au);
        if (dret == (s32)VDEC_ERROR_BUSY) {
            if (retries == 0) {
                char buf[80];
                snprintf(buf, sizeof(buf), "BUSY: au_done=%d frames=%d",
                    s_au_done, s_frames_ready);
                plog(buf);
            }
            usleep(5000);
            retries++;
        }
    } while (dret == (s32)VDEC_ERROR_BUSY && retries < 200);

    if (dret != 0) {
        char buf[64];
        snprintf(buf, sizeof(buf), "AU#%d FAIL ret=0x%08x retries=%d",
            s_au_submitted-1, (unsigned)dret, retries);
        plog(buf);
        return;
    }

    // After first IDR: dump leading bytes and wait 3s to test if callback fires.
    if (has_idr) {
        char hexbuf[80]; int ho = 0;
        int dump = len < 16 ? len : 16;
        for (int b = 0; b < dump; b++)
            ho += snprintf(hexbuf + ho, sizeof(hexbuf) - ho, "%02x ", au_buf[b]);
        plog(hexbuf);
        plog("IDR submitted OK - waiting 3s for callback...");
        for (int w = 0; w < 3000; w++) usleep(1000);
        char buf[96];
        snprintf(buf, sizeof(buf), "3s-wait: cb_done=%d cb_pic=%d vdec_err=%d",
            s_au_done, s_frames_ready, (int)s_vdec_error);
        plog(buf);
    }
}

// -------------------------------------------------------
// Audio — silence output to keep the audio clock alive
// -------------------------------------------------------

static u32             s_audio_port  = 0;
static sys_event_queue_t s_audio_eq  = {0};
static sys_ipc_key_t   s_audio_key  = 0;
static bool            s_audio_ok   = false;

static void audio_open(void) {
    if (audioInit() != 0) return;

    audioPortParam p;
    p.numChannels = AUDIO_PORT_2CH;
    p.numBlocks   = AUDIO_BLOCK_8;
    p.attrib      = 0;
    p.level       = 1.0f;
    if (audioPortOpen(&p, &s_audio_port) != 0) { audioQuit(); return; }
    if (audioCreateNotifyEventQueue(&s_audio_eq, &s_audio_key) != 0) {
        audioPortClose(s_audio_port); audioQuit(); return;
    }
    audioSetNotifyEventQueue(s_audio_key);
    audioPortStart(s_audio_port);
    s_audio_ok = true;
}

static void audio_silence(void) {
    if (!s_audio_ok) return;
    audioPortConfig cfg;
    audioGetPortConfig(s_audio_port, &cfg);
    sys_event_t ev;
    if (sysEventQueueReceive(s_audio_eq, &ev, 1000) != 0) return; // 1 ms timeout
    float *buf = (float*)(uintptr_t)(u32)cfg.audioDataStart;
    u64    ch  = cfg.channelCount;
    memset(buf + cfg.readIndex * ch * AUDIO_BLOCK_SAMPLES, 0,
           (size_t)(ch * AUDIO_BLOCK_SAMPLES * sizeof(float)));
}

static void audio_close(void) {
    if (!s_audio_ok) return;
    audioPortStop(s_audio_port);
    audioRemoveNotifyEventQueue(s_audio_key);
    audioPortClose(s_audio_port);
    sysEventQueueDestroy(s_audio_eq, 0);
    audioQuit();
    s_audio_ok = false;
}

// -------------------------------------------------------
// Helper — wait for O with error message
// -------------------------------------------------------

static void show_error(const char *line1, const char *line2) {
    drawHeader();
    drawText(40, 100, line1);
    if (line2 && line2[0]) drawText(40, 130, line2);
    drawText(40, 160, "O: back");
    flip();
    init_btns();
    padInfo pi; padData pd;
    while (running) {
        sysUtilCheckCallback();
        ioPadGetInfo(&pi);
        for (int i = 0; i < MAX_PADS; i++) {
            if (!pi.status[i]) continue;
            ioPadGetData(i, &pd); update_buttons(&pd);
            if (BTN_PRESSED(circle)) return;
        }
    }
}

// -------------------------------------------------------
// show_player — public entry point
// -------------------------------------------------------

void show_player(const JFItem *item) {
    plog("show_player: enter");

    // Generate a unique session ID so Jellyfin tracks this transcode session.
    char session_id[32];
    snprintf(session_id, sizeof(session_id), "ps3-%u", (unsigned)time(NULL));

    // Build Jellyfin MPEG-TS stream URL
    char url[640];
    // H.264 level 3.1 caps at 1280x720 @ 30fps (3600 macroblocks max).
    u32 req_w = display_width  < 1280 ? display_width  : 1280;
    u32 req_h = display_height < 720  ? display_height : 720;
    // Use /stream.ts (container in path) — this is how Jellyfin clients
    // signal a TS transcode request. Container= in query params alone is
    // often ignored; the path extension is the reliable trigger.
    snprintf(url, sizeof(url),
        "%s/Videos/%s/stream.ts"
        "?VideoCodec=h264"
        "&MaxWidth=%u&MaxHeight=%u"
        "&VideoBitrate=4000000"
        "&AudioCodec=aac&AudioBitrate=192000"
        "&MaxAudioChannels=2"
        "&DeviceId=ps3&Static=false"
        "&MediaSourceId=%s&PlaySessionId=%s",
        g_server, item->id, req_w, req_h, item->id, session_id);
    plog(url);

    // ---- VDEC init ----
    plog("show_player: drawHeader");
    drawHeader();
    drawTextf(40, 100, "%.70s", item->name);
    drawText(40, 130, "Initializing decoder...");
    flip();

    plog("show_player: vdec_open");
    if (!vdec_open()) {
        plog("show_player: vdec_open FAILED");
        vdec_close();
        show_error("VDEC init failed.", "See /dev_hdd0/tmp/player_log.txt");
        return;
    }
    plog("show_player: vdec_open OK");

    // ---- Audio init (best-effort) ----
    plog("show_player: audio_open");
    audio_open();
    plog("show_player: audio_open done");

    // ---- Connect to stream ----
    drawHeader();
    drawTextf(40, 100, "%.70s", item->name);
    drawText(40, 130, "Connecting to stream...");
    flip();

    plog("show_player: stream_open");
    int sock = stream_open(url);
    if (sock < 0) {
        plog("show_player: stream_open FAILED");
        audio_close();
        vdec_close();
        show_error("Stream connection failed.", url);
        return;
    }
    plog("show_player: stream_open OK");

    // Tell the user streaming has started so they don't press O thinking it froze.
    drawHeader();
    drawTextf(40, 100, "%.70s", item->name);
    drawText(40, 130, "Streaming... START=stop");
    flip();

    s_au_submitted = 0;
    s_got_sps      = false;
    s_au_buf_idx   = 0;

    // ---- Playback loop ----
    // Large buffers kept static — only one player runs at a time.
    static TSState ts;
    static u8 pes_out[512 * 1024];
    int pes_out_len = 0;
    u8  ts_pkt[TS_PACKET_SIZE];

    memset(&ts, 0, sizeof(ts));
    init_btns();
    bool playing          = true;
    bool first_pkt        = true;
    bool first_frame      = true;
    int  gret_log_count   = 0;  // log first 3 vdecGetPicture results
    plog("show_player: entering decode loop");

    while (running && playing && !s_vdec_error) {
        sysUtilCheckCallback();

        padInfo pi; padData pd;
        ioPadGetInfo(&pi);
        for (int i = 0; i < MAX_PADS; i++) {
            if (!pi.status[i]) continue;
            ioPadGetData(i, &pd); update_buttons(&pd);
            if (BTN_PRESSED(start)) { playing = false; break; }
        }
        if (!playing) break;

        // Read one TS packet; stream_read returns 0 on timeout (SO_RCVTIMEO),
        // letting us loop back and check buttons again.  -1 = disconnected.
        int rd = stream_read(sock, ts_pkt, TS_PACKET_SIZE);
        if (rd < 0) { plog("show_player: stream disconnected"); break; }
        if (rd == 0) continue; // timeout — no data yet, go check buttons again

        if (first_pkt) {
            char buf[48];
            snprintf(buf, sizeof(buf), "show_player: first pkt byte=0x%02x", ts_pkt[0]);
            plog(buf);
            first_pkt = false;
        }

        // Demux and reassemble PES
        if (ts_process(&ts, ts_pkt, pes_out, &pes_out_len)) {
            const u8 *h264; int h264_len;
            if (pes_payload(pes_out, pes_out_len, &h264, &h264_len)) {
                vdec_submit(h264, h264_len);
            }
        }

        // Drain decoded frames — poll directly so we don't depend on the callback
        while (s_frames_ready > 0) s_frames_ready--;
        for (int poll = 0; poll < 8; poll++) {
            vdecPictureFormat fmt;
            fmt.format_type  = VDEC_PICFMT_ARGB32;
            fmt.color_matrix = VDEC_COLOR_MATRIX_BT709;
            fmt.alpha        = 0xFF;

            s32 gret = vdecGetPicture(s_vdec, &fmt, s_frame_buf);
            if (gret_log_count < 3) {
                char buf[80];
                snprintf(buf, sizeof(buf), "getPic gret=0x%08x poll=%d au=%d cb_done=%d cb_pic=%d",
                    (unsigned)gret, poll, s_au_submitted, s_au_done, s_frames_ready);
                plog(buf);
                gret_log_count++;
            }
            if (gret != 0) break;
            if (first_frame) { plog("show_player: first frame displayed"); first_frame = false; }
            waitflip();
            u32 pixels = display_width * display_height;
            memcpy(color_buffer[curr_fb], s_frame_buf, pixels * sizeof(u32));
            flip();
            audio_silence();
        }
    }

    {
        char buf[96];
        snprintf(buf, sizeof(buf), "show_player: loop exit running=%u playing=%d vdec_err=%d",
                 running, (int)playing, (int)s_vdec_error);
        plog(buf);
    }
    netClose(sock);
    audio_close();
    vdec_close();

    // Restore the UI render target so the menu can draw again
    setRenderTarget(curr_fb);
    init_btns();

    plog("show_player: done");
}
